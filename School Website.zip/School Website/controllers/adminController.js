const Admin = require("../models/Admin");
const controller = require("../controllers/adminController");

// GET login page
exports.getLogin = (req, res) => {
  res.render("pages/admin/login", { error: null });
};

// POST login
exports.postLogin = async (req, res) => {
  const { email, password } = req.body;
  const admin = await Admin.findOne({ email, password }); // For now, plain password

  if (!admin) return res.render("pages/admin/login", { error: "Invalid credentials" });

  req.session.admin = admin._id;
  res.redirect("/admin/dashboard");
};

// GET logout
exports.logout = (req, res) => {
  req.session.destroy(() => {
    res.redirect("/admin/login");
  });
};

// GET dashboard
exports.dashboard = (req, res) => {
  res.render("pages/admin/dashboard");
};